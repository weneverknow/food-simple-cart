import 'package:diyo_test/src/features/tables/domain/entities/diyo_table.dart';

final tables = [
  DiyoTable(id: "diyo-001", name: "Meja Diyo 1"),
  DiyoTable(id: "diyo-002", name: "Meja Diyo 2"),
  DiyoTable(id: "diyo-003", name: "Meja Diyo 3"),
  DiyoTable(id: "diyo-004", name: "Meja Diyo 4")
];
