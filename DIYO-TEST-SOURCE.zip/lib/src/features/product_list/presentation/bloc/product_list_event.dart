part of 'product_list_bloc.dart';

abstract class ProductListEvent extends Equatable {
  // const ProductListEvent();

  // @override
  // List<Object> get props => [];
}

class ProductListLoad extends ProductListEvent {
  @override
  // TODO: implement props
  List<Object?> get props => [];
}
