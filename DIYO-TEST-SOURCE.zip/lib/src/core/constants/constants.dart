import 'package:flutter/material.dart';

const defaultPadding = 24.0;

const primaryColor = Color.fromARGB(255, 236, 45, 45);
const secondaryColor = Color(0xffCA0E0E);
